(function () {
  'use strict';

  var rootStyle = getComputedStyle(document.documentElement);
  var accent = rootStyle.getPropertyValue('--accent').trim();
  var accent2 = rootStyle.getPropertyValue('--accent2').trim();
  var ink = rootStyle.getPropertyValue('--ink').trim();
  var muted = rootStyle.getPropertyValue('--muted').trim();
  var rule = rootStyle.getPropertyValue('--rule').trim();
  var bg2 = rootStyle.getPropertyValue('--bg2').trim();
  var surface = rootStyle.getPropertyValue('--surface').trim();

  if (window.mermaid) {
    mermaid.initialize({
      startOnLoad: true,
      theme: 'base',
      securityLevel: 'loose',
      flowchart: { curve: 'basis', htmlLabels: true },
      themeVariables: {
        primaryColor: bg2,
        primaryTextColor: ink,
        primaryBorderColor: accent,
        lineColor: muted,
        secondaryColor: surface,
        tertiaryColor: bg2,
        fontFamily: 'Instrument Sans'
      }
    });
  }

  var parameterEl = document.getElementById('chart-parameters');
  if (parameterEl && window.echarts) {
    var parameterChart = echarts.init(parameterEl, null, { renderer: 'svg' });
    parameterChart.setOption({
      animation: false,
      color: [accent, accent2, muted],
      tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow' },
        appendToBody: true,
        formatter: function (items) {
          var item = items[0];
          var note = item.name === '主模型' ? '官方规模口径' :
            item.name === 'N-gram Embedding' ? '额外静态记忆参数' :
            '每 token 激活口径；不可与前两项相加';
          return '<strong>' + item.name + '</strong><br>' + item.value + 'B<br><span>' + note + '</span>';
        }
      },
      grid: { left: 28, right: 32, top: 18, bottom: 30, containLabel: true },
      xAxis: {
        type: 'value',
        max: 140,
        name: '十亿参数（B）',
        nameTextStyle: { color: muted },
        axisLabel: { color: muted },
        axisLine: { lineStyle: { color: rule } },
        splitLine: { lineStyle: { color: rule } }
      },
      yAxis: {
        type: 'category',
        inverse: true,
        data: ['主模型', 'N-gram Embedding', '每 token 激活'],
        axisLabel: { color: ink, fontWeight: 600 },
        axisTick: { show: false },
        axisLine: { lineStyle: { color: rule } }
      },
      series: [{
        name: '参数',
        type: 'bar',
        data: [
          { value: 125, itemStyle: { color: accent } },
          { value: 51, itemStyle: { color: accent2 } },
          { value: 6, itemStyle: { color: muted } }
        ],
        barWidth: 28,
        label: {
          show: true,
          position: 'right',
          color: ink,
          fontWeight: 700,
          formatter: '{c}B'
        }
      }]
    });
    window.addEventListener('resize', function () { parameterChart.resize(); });
  }

  var layerEl = document.getElementById('chart-layers');
  if (layerEl && window.echarts) {
    var layerChart = echarts.init(layerEl, null, { renderer: 'svg' });
    layerChart.setOption({
      animation: false,
      color: [accent, accent2],
      tooltip: {
        trigger: 'item',
        appendToBody: true,
        formatter: function (item) {
          return '<strong>' + item.name + '</strong><br>' + item.value + ' 层（' + item.percent + '%）';
        }
      },
      legend: {
        bottom: 0,
        textStyle: { color: muted },
        itemWidth: 12,
        itemHeight: 12
      },
      series: [{
        type: 'pie',
        radius: ['48%', '72%'],
        center: ['50%', '44%'],
        avoidLabelOverlap: true,
        label: {
          color: ink,
          fontWeight: 700,
          formatter: '{b}\n{c} 层'
        },
        labelLine: { lineStyle: { color: rule } },
        data: [
          { value: 36, name: 'GDN' },
          { value: 12, name: 'QSA' }
        ]
      }],
      graphic: [{
        type: 'text',
        left: 'center',
        top: '37%',
        style: {
          text: '48\n层',
          textAlign: 'center',
          fill: ink,
          fontSize: 20,
          fontWeight: 700,
          lineHeight: 24
        }
      }]
    });
    window.addEventListener('resize', function () { layerChart.resize(); });
  }
})();
